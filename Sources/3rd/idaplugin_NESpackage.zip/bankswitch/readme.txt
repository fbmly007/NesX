
	Nintendo Entertainment System (NES) bank switcher
	------------------------------------------------------
	Copyright 2006, Dennis Elser (dennis@backtrace.de)


	IDA Pro plugin module for Nintendo Enternainment System
    (NES) ROM images in iNES file format.
    
  
  This plugin simulates the bank switching (paging)
  mechanism of the NES.



	Copy compiled plugin to idadir%/plugins/bankswitch.plw


    Please send me an e-mail if you find any bugs!

	(c) 2006, Dennis Elser (dennis@backtrace.de)