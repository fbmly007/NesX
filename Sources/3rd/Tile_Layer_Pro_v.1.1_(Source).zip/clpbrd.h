#ifndef __CLPBRD_H__
#define __CLPBRD_H__

typedef struct {
    BYTE *data;
    TTileFormat fmt;
} CLIPITEM;

#endif