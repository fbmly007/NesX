Build with Borland C++ Builder 3 (or higher?)
Please give credit if you use any of it.
